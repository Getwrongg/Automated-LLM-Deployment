const express = require('express');
const axios = require('axios');
const { Ollama } = require('ollama');

const app = express();
const port = 3011; // Ollama Query App runs on this port

app.use(express.json());

// ** Map Event Types to Corresponding Agent URLs **
const AGENT_URLS = {
    "server_info": "http://xrpl-api:3010/api/monitoring/server-info",
    "server_state": "http://xrpl-api:3010/api/monitoring/server-state",
    "account_info": "http://xrpl-api:3010/api/accounts"
};

//"trade_history": "http://localhost:3003/trade/history",
//    "save_trade": "http://localhost:3003/trade/save",
//        "check_trade": "http://localhost:3003/trade/check",
//            "risk_config": "http://localhost:3004/risk/config",
//                "xrpl_network": "http://localhost:3002/network/get",
//                    "transactions": "http://localhost:3002/transactions",
//    "ledger": "http://localhost:3002/ledger",



// ?? Ollama Query: Fetch Data from Relevant Agents & Process AI Query
app.post('/query', async (req, res) => {
    const { prompt, model, eventTypes } = req.body;

    if (!prompt || !eventTypes || !Array.isArray(eventTypes)) {
        return res.status(400).json({ error: 'Prompt and eventTypes array are required' });
    }

    try {
        let eventData = {};

        // ** Fetch data only from the specified event types **
        await Promise.all(eventTypes.map(async (event) => {
            const endpoint = AGENT_URLS[event]; // Find the corresponding agent URL
            if (endpoint) {
                try {
                    const response = await axios.get(endpoint);
                    eventData[event] = response.data;
                } catch (error) {
                    console.error(`Failed to fetch ${event} data from ${endpoint}:`, error.message);
                    eventData[event] = "Error retrieving data";
                }
            }
        }));

        // ** Directly pass eventData to Ollama without extra formatting **
        const ollama = new Ollama();
        const response = await ollama.generate({
            model: model || "mistral", // Default model if not provided
            prompt: JSON.stringify({ prompt, eventData }) // Send only necessary data
        });

        res.json({ response });

    } catch (err) {
        res.status(500).json({ error: 'Failed to query Ollama', details: err.message });
    }
});

// Start Express Server
app.listen(port, () => {
    console.log(`Ollama Query App running on port ${port}`);
});
